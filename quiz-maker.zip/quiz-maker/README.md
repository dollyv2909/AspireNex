# quiz-generator
**Quiz generator**
Keyword based quiz generator-
1. Enter new questions, add tags based on various aspects like location, feature, etc
2. Retrive random realted questions by entering tags

Implemented this project for the Database Management systems course at College of Engineering Pune
