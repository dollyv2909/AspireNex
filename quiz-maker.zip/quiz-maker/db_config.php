<?php

define('DB_USER', "u523142629_ctt"); // db user
define('DB_PASSWORD', "ramanand"); // db password (mention your db password here)
define('DB_DATABASE', "u523142629_ctt"); // database name
define('DB_SERVER', "mysql.hostinger.in"); // db server


?>