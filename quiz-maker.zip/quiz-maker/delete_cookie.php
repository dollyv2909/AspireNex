<?php


setcookie("authorization","no" );
setcookie("type","don't_know" );


exit();

?>